﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Node : MonoBehaviour
{

    public Color hoverColer;
    public Vector3 positionOffset;

    private Renderer rend;
    private Color startColor;

    private GameObject turret;

    void Start()
    {
        rend = GetComponent<Renderer>();
        startColor = rend.material.color;
                
    }

    //Prevent placing turret in invalid location if turret is already present
    private void OnMouseDown()
    {
        if(turret != null)
        {
            Debug.Log("Can't Build here - Need to display this on screen");
        }
        //build a turret
        GameObject turretToBuild = BuildManager.instance.GetTurretToBuild();
        turret = (GameObject)Instantiate(turretToBuild, transform.position + positionOffset, transform.rotation);

    }
    //creates color change on hover over node
    void OnMouseEnter()
    {
        rend.material.color = hoverColer;
    }
    //returns color to normal after hover is over
    void OnMouseExit()
    {
        rend.material.color = startColor;
    }
}
