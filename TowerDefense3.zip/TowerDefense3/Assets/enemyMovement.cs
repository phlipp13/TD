﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyMovement : MonoBehaviour {

    public static Transform target;
    public GameObject Base;
    public float speed = 5f;
    public Vector3 TargetPosition;

    //New Movement Mechanic Variables
    public string groundTag = "ground";

    public void Seek()
    {
        Vector3 dir = target.position - transform.position;
        float distanceThisFrame = speed * Time.deltaTime;
        transform.Translate(dir.normalized * distanceThisFrame, Space.World);
        
    }


    // Use this for initialization
    void Start ()
    {
        InvokeRepeating("updateTarget", 0f, .5f);

        //target = GameObject.Find("Base").transform;
        //TargetPosition = target.position;
        
    }
	void updateTarget()
    {
        GameObject[] waypoints = GameObject.FindGameObjectsWithTag(groundTag);
        float shortestDistance = Mathf.Infinity;
        GameObject nearestWayPoint = null;
        foreach (GameObject waypoint  in waypoints)
        {
            float distanceToWaypoint = Vector3.Distance(transform.position, waypoint.transform.position);
            if (distanceToWaypoint < shortestDistance)
            {
                shortestDistance = distanceToWaypoint;
                nearestWayPoint = waypoint;
            }
        }
        
        
            target = nearestWayPoint.transform;
        
        //Vector3 dir = target.position - transform.position;
        //float distanceThisFrame = speed * Time.deltaTime;

        //transform.Translate(dir.normalized * distanceThisFrame, Space.World);
    }

	// Update is called once per frame
	void Update ()
    {
        
        Seek();
        
	}
}
