﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameMaster : MonoBehaviour {
    public int currentenemies = EnemySpawn.currentEnemies;
    public Text waveCountdownTimer;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        waveCountdownTimer.text = currentenemies.ToString();
	}
}
