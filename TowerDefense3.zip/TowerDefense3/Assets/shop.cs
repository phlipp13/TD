﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shop : MonoBehaviour
{
    BuildManager buildmanager;

    private void Start()
    {
        buildmanager = BuildManager.instance;
    }

    public void PurchaseStartingTower()
    {
        Debug.Log("Rifle Tower Purhcased");
        buildmanager.SetTurretToBuild(buildmanager.rifleTower);
    }

    public void PurchaseMeleeTower()
    {
        Debug.Log("Melee Tower Purhcased");
        buildmanager.SetTurretToBuild(buildmanager.meleeTower);
        return;
    }
    public void PurchaseSplashTower()
    {
        Debug.Log("Splash Tower Purhcased");
        buildmanager.SetTurretToBuild(buildmanager.splashTower);
        return;
    }

}
