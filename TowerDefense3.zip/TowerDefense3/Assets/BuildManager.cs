﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildManager : MonoBehaviour
{

    public static BuildManager instance;
    public GameObject rifleTower;
    public GameObject meleeTower;
    public GameObject splashTower;
    public GameObject turretToBuild;


    void Awake()
    {
        if(instance != null)
        {
            Debug.Log("Multiple Build Managers in scene");
        }
        instance = this;
    }


    void Start()
    {
        turretToBuild = rifleTower;
    }


    public GameObject GetTurretToBuild()
    {
        return turretToBuild;
    }

    public void SetTurretToBuild(GameObject tower)
    {
       turretToBuild = turretToBuild;
    }
	
}
