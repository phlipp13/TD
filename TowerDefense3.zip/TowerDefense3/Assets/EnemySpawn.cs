﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemySpawn : MonoBehaviour {

    public GameObject[] enemies;
    private int maxEnemies = 2;
    public static int currentEnemies = 0;
    public int waveNumber = 1;
    public float waveCountdown = 5f;
    public static Text waveCountdownText;

	// Use this for initialization
	void Start ()
    {
    
        
            SpawnEnemies();
        
        
    }
    void Update()
    {
        //waveCountdownText.text = currentEnemies.ToString();
    }


    void SpawnEnemies()
    {
        for (int currentEnemies = 0; currentEnemies < maxEnemies; currentEnemies++)
        {
            int random = Random.Range(0, enemies.Length);
            Instantiate(enemies[random], transform.position, Quaternion.identity);

            currentEnemies++;
            
        }
        
    }

    void CountDown()
    {

    }
    

}
